<div class="cs-preloader-logo">
  <?php $this->view( 'svg/logo-flat-original' ); ?>
</div>
<div class="cs-preloader-text"><?php _e( 'Powered by Themeco', csl18n() ); ?></div>